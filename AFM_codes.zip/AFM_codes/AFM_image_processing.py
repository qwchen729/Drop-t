import pandas as pd
import matplotlib.pyplot as plt
import os
import numpy as np
from matplotlib.pyplot import figure
from collections import Counter
from scipy.stats import mannwhitneyu
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['svg.fonttype']='none'

"""
the physical size of each 512*512 pixel picture, to calculate the DNA length
"""
picture_size_dict = {'3C':{'1.424':4.35,'1.428':4,'4.024':4.32,'4.029':2.65,'K562_3C.0_00006':4.2,'K562_3C.0_00016':4.9,'K562_3C.0_00019':10,'K562_3C.0_00022':4.73,'K562_3C.0_00024':2.9,'E_no.020':4.9,'E_no.023':4.9},
                     'plasmid':{'P.0_00014':4,'P.0_00006':6.45,'E_no.035':3.27,'E_no.041':4.81,'1.468':4.5,'1.455':5.1,'1.451':3,'1.441':10,'1.471':5.7,'1.444':5.0},
                     'unligated':{'5.014':2.60,'K562_ul.0_00000':2.67,'12.022':3.3}}
from sklearn.neighbors import NearestNeighbors

"""
this code is used to get branch points from the endpoints of all branches
"""

def count_intersection_from_detail(group,branch_cutoff = 8,distance_threshold=3):
    group = group.copy()
    group = group[group['Euclidean distance']>0]
    all_points = list(zip(group['V1 x'],group['V1 y']))+list(zip(group['V2 x'],group['V2 y']))
    counter_dict = Counter(all_points) # 每个点出现的次数
    end_point_pairs = list(zip(list(zip(group['V1 x'],group['V1 y'])),list(zip(group['V2 x'],group['V2 y']))))
    end_point_counts = [(counter_dict[i[0]],counter_dict[i[1]]) for i in end_point_pairs]
    
    group['long branch'] = group['Branch length']>branch_cutoff
    group['is not end'] = [np.min(i)>1 for i in end_point_counts]
    #group = group[np.logical_or(,group['is not end'])]
    
    group['score'] = [np.min([2,sum(i)]) for i in list(zip(2*group['long branch'],group['is not end']))] #长branch +2分，是中间+1分，要求至少5分
    #print(group)
    
    all_points_score1 = list(zip(list(zip(group['V1 x'],group['V1 y'])),group['score']))
    all_points_score2 = list(zip(list(zip(group['V2 x'],group['V2 y'])),group['score']))
    
    #print(group)
    all_points_score = {}
    for lst in [all_points_score1,all_points_score2]:
        for point,score in lst:
            try:
                all_points_score[point] += score
            except KeyError:
                all_points_score[point] = score
    counter_dict = Counter(all_points)
    intersects = [i for i in all_points_score.keys() if all_points_score[i]>=5]
    intersection_num = len(intersects)
    #对每个intersect，看它所在的所有branch
    #print(intersects)
    #aggregated_points, labels = aggregate_points(intersects, distance_threshold=distance_threshold)
    #print(len(intersects),len(aggregated_points))
    return intersection_num,intersects
def find_nearest_points_sklearn(points1, points2):
    """
    使用scikit-learn的NearestNeighbors
    """
    points1 = np.asarray(points1)
    points2 = np.asarray(points2)
    
    # 构建最近邻模型
    nn = NearestNeighbors(n_neighbors=1, algorithm='kd_tree')
    nn.fit(points2)  # 在集合2上训练
    
    # 查询
    distances, indices = nn.kneighbors(points1)
    
    # 展平结果
    distances = distances.flatten()
    indices = indices.flatten()
    nearest_points = points2[indices]
    
    return indices, nearest_points, distances
def get_points_from_detail(detail_file):
    detail = pd.read_csv(detail_file)
    skeleton_intersection_dict = {}
    intersects_dict = {}
    for skeleton,group in detail.groupby('Skeleton ID'):
        intersection_num,intersects = count_intersection_from_detail(group,branch_cutoff=8)
        skeleton_intersection_dict[skeleton] = intersection_num
        intersects_dict[skeleton] = intersects
    points =  [coord for skeleton in intersects_dict.keys() for coord in intersects_dict[skeleton]]
    return points
def pipeline_new_skeleton(experiment,file,size_cut=2):  #以skeleton为中心，找intersection
    #Counts = pd.read_csv('Counts_1.424_nano.csv')
    try:
        Results = pd.read_csv(f'{experiment}/Counts_{file}_nano_Results.csv')
    except FileNotFoundError:
        Results = get_points_from_detail(f'{experiment}/{file}_detail_filt.csv')
        Results = pd.DataFrame(Results,columns=['X','Y'])
    Details = pd.read_csv(f'{experiment}/{file}_details_new.csv')
    
    all_skeletons = set(Details['Skeleton ID'])
    groups = Details.groupby('Skeleton ID')
    mol_size_dict = {skeleton:picture_size_dict[experiment][file]/512/0.3*np.sum(groups.get_group(skeleton)['Branch length']) for skeleton in all_skeletons}
    
    big_skeleton = set([i for i in mol_size_dict if mol_size_dict[i]>=size_cut])
    Details = Details[Details['Skeleton ID'].isin(big_skeleton)]
    #print(Results)
    counter_points = list(zip(Results['X'],Results['Y']))
    Details_dict = dict([i for i in zip(zip(Details['V1 x'],Details['V1 y']),Details['Skeleton ID'])])
    dict2 = dict([i for i in zip(zip(Details['V2 x'],Details['V2 y']),Details['Skeleton ID'])])
    #print(len(Details_dict),len(dict2))
    Details_dict.update(dict2)
    #print(len(Details_dict))
    indices, nearest_points, distances = find_nearest_points_sklearn(counter_points,list(Details_dict.keys()))
    Results['distances'] = distances
    Results['Skeleton'] = [Details_dict[tuple(i)] for i in nearest_points]
    Results = Results[Results['distances']<5]
    from collections import defaultdict
    intersection_dict = Counter(list(Results['Skeleton']))
    
    for i in mol_size_dict:
        if i not in intersection_dict:
            intersection_dict[i] = 0
    intersection_per_kb = {i:intersection_dict[i]/mol_size_dict[i] for i in mol_size_dict if mol_size_dict[i]>size_cut}
    return mol_size_dict,intersection_dict,intersection_per_kb
def remove_outliers(lst,cut=0.05):
    low = np.quantile(lst,cut)
    high = np.quantile(lst,1-cut)
    return [i for i in lst if i>=low and i<=high]
def get_result_dict(files_dict,branch_cutoff=8):
    result_dict = {}
    for experiment in files_dict:
        result_dict[experiment] = {}
        for file in files_dict[experiment]:
            detail = pd.read_csv(f'{experiment}/{file}_detail_filt.csv')
            result = pd.read_csv(f'{experiment}/{file}_result_filt.csv')
            result = result.rename(columns={' ': 'Skeleton ID'})
            passed_skeleton = get_passed_skeleton(detail,branch_len_cut[experiment],branch_num_cut[experiment],total_len_cut[experiment])
            passed_result = result[result['Skeleton ID'].isin(passed_skeleton)].copy()
            passed_detail = detail[detail['Skeleton ID'].isin(passed_skeleton)].copy()
            mol_len_dict = dict(zip(passed_result['Skeleton ID'],passed_result['# Branches']*passed_result['Average Branch Length']))
            mol_intersect_dict = {}
            x = detail[detail['Skeleton ID']==1]
            #break
            for skeleton,group in detail.groupby('Skeleton ID'):
                intersection_num,intersects = count_intersection_from_detail(group,branch_cutoff=branch_cutoff)
                mol_intersect_dict[skeleton] = intersection_num
                #print(skeleton,intersection_num)
            result_dict[experiment][file] = {key:(mol_len_dict[key]*picture_size_dict[experiment][file]/512/0.34,mol_intersect_dict[key]) for key in mol_len_dict.keys()}
        #break
    return result_dict


group_dict = {'3C':[['E_no.020','E_no.023'],['K562_3C.0_00006','K562_3C.0_00016'],['1.424','1.428']],
             'plasmid':[['E_no.035','E_no.041'],['P.0_00006','P.0_00014'],['1.444','1.451','1.455','1.468','1.471']]}
intersect_per_kb_dict = {}
mol_intersection_dict = {}
order = [0,3,1,4,2,5]
len_dict = {}
size_cut_dict = {'3C':2,'plasmid':2,'unligated':0.2}
figure(figsize=(3,3))
for experiment in group_dict:
    print(experiment)
    for k,group in enumerate(group_dict[experiment]):
        all_intersect_per_kb = []
        all_mol_intersection = []
        for file in group:
            mol_size_dict,intersection_dict,intersection_per_kb = pipeline_new_skeleton(experiment,file,size_cut=size_cut_dict[experiment])
            all_intersect_per_kb.extend(list(intersection_per_kb.values()))
            all_mol_intersection.extend([(mol_size_dict[i],intersection_dict[i]) for i in intersection_per_kb])
        intersect_per_kb_dict[f'{experiment[:2]}-{k}'] = all_intersect_per_kb
        mol_intersection_dict[f'{experiment[:2]}-{k}'] = all_mol_intersection
        len_dict[f'{experiment[:2]}-{k}'] = len(all_intersect_per_kb)
        #print(len(all_intersect_per_kb),f'{experiment[:2]}-{k}')
to_plots = list(intersect_per_kb_dict.values())
to_plots = [remove_outliers(i) for i in to_plots]
for i in range(len(group_dict['3C'])):
    print(mannwhitneyu(intersect_per_kb_dict[f'3C-{i}'], intersect_per_kb_dict[f'pl-{i}'], alternative='greater'))
if order is not None:
    to_plots = [to_plots[i] for i in order]
plt.boxplot(to_plots)
for i, d in enumerate(to_plots):
    y = d
    x = np.random.normal(i+1, 0.04, len(y))
    plt.scatter(x, y, alpha=0.5)
if order is None:
    plt.xticks([i+1 for i in range(len(intersect_per_kb_dict))],intersect_per_kb_dict.keys())
else:
    plt.xticks([i+1 for i in range(len(intersect_per_kb_dict))],[f'{list(intersect_per_kb_dict.keys())[i]}\nn={len_dict[list(intersect_per_kb_dict.keys())[i]]}' for i in order])
plt.ylabel('intersections per kb')
#return all_intersect_per_kb
#diff_3C_batch = heterogeneity_batch(result_dict_total,group_dict,min_kb=5,order = [0,3,1,4,2,5])
plt.plot([2.5,2.5],[0,1.4],color='black')
plt.plot([4.5,4.5],[0,1.4],color='black')
x1, x2 = 1,2
y,h = 1.4,0.02
plt.plot([x1, x1, x2, x2], [y, y+h, y+h, y], lw=1, c="k")
plt.text((x1+x2)*0.5, y+h, "p=1e-11", ha='center', va='bottom', color="k", fontsize=10)
x1, x2 = 3,4
y,h = 1.4,0.02
plt.plot([x1, x1, x2, x2], [y, y+h, y+h, y], lw=1, c="k")
plt.text((x1+x2)*0.5, y+h, "p=1e-9", ha='center', va='bottom', color="k", fontsize=10)
x1, x2 = 5,6
y,h = 1.4,0.02
plt.plot([x1, x1, x2, x2], [y, y+h, y+h, y], lw=1, c="k")
plt.text((x1+x2)*0.5, y+h, "p=0.11", ha='center', va='bottom', color="k", fontsize=10)
plt.savefig('3C_plasmid_groups.png')
plt.clf()


group_dict = {'3C':[['E_no.020','E_no.023'],['K562_3C.0_00006','K562_3C.0_00016'],['1.424','1.428'],['4.024','4.029']],
             'plasmid':[['E_no.035','E_no.041'],['P.0_00006','P.0_00014'],['1.444','1.451','1.455','1.468','1.471']],
             'unligated':[['5.014'],['K562_ul.0_00000'],['12.022']]}
used_pictures = {experiment:[j for i in group_dict[experiment] for j in i] for experiment in group_dict}
experiments = ['3C','plasmid','unligated']
size_cut_dict = {'3C':2,'plasmid':2,'unligated':0.2}
#files_dict_total = {}
#for experiment in experiments:
#    files_dict_total[experiment] = sorted(list(set([i.split('_detail_filt.csv')[0] for i in group_dict[experiment]])))
files_dict_total = used_pictures

#result_dict_total = get_result_dict(files_dict_total,branch_cutoff=8)
#non = plot_scatter_result(result_dict_total)
#intersect_per_kb_dict = calculate_intersect_per_kb(result_dict_total,min_kb=5)

intersect_per_kb_dict = {experiment:[] for experiment in used_pictures}
mol_intersection_dict = {experiment:[] for experiment in used_pictures}
result_dict = {}
for experiment in used_pictures:
    result_dict[experiment] = {}
    for file in used_pictures[experiment]:
        mol_size_dict,intersection_dict,intersection_per_kb = pipeline_new_skeleton(experiment,file,size_cut=size_cut_dict[experiment])
        intersect_per_kb_dict[experiment].extend(list(intersection_per_kb.values()))
        mol_intersection_dict[experiment].extend([(mol_size_dict[i],intersection_dict[i]) for i in intersection_per_kb])
        #break

figure(figsize=(3,3))
to_plots = list(intersect_per_kb_dict.values())
to_plots = [remove_outliers(i) for i in to_plots]

plt.boxplot(to_plots)
for i, d in enumerate(to_plots):
    y = d
    x = np.random.normal(i+1, 0.04, len(y))
    plt.scatter(x, y, alpha=0.5)
print(mannwhitneyu(intersect_per_kb_dict['3C'], intersect_per_kb_dict['plasmid'], alternative='greater'))
print(mannwhitneyu(intersect_per_kb_dict['3C'], intersect_per_kb_dict['unligated'], alternative='greater'))
plt.xticks([1,2,3],[f'3C\nn={len(to_plots[0])}',f'plasmid\nn={len(to_plots[1])}',f'unligated\nn={len(to_plots[2])}'])
plt.ylabel('intersections per kb')

x1, x2 = 1,2
y,h = 1.4,0.02
plt.plot([x1, x1, x2, x2], [y, y+h, y+h, y], lw=1, c="k")
plt.text((x1+x2)*0.5, y+h, "****", ha='center', va='bottom', color="k", fontsize=10)
x1, x2 = 1,3
y,h = 1.7,0.02
plt.plot([x1, x1, x2, x2], [y, y+h, y+h, y], lw=1, c="k")
plt.text((x1+x2)*0.5, y+h, "****", ha='center', va='bottom', color="k", fontsize=10)
plt.savefig('3C_plasmid_unligated.png')
plt.clf()