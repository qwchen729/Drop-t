
"""
this code is used to get branch points from the endpoints of all branches
"""

def count_intersection_from_detail(group,branch_cutoff = 8,distance_threshold=3):
    group = group.copy()
    group = group[group['Euclidean distance']>0]
    all_points = list(zip(group['V1 x'],group['V1 y']))+list(zip(group['V2 x'],group['V2 y']))
    counter_dict = Counter(all_points) # 每个点出现的次数
    end_point_pairs = list(zip(list(zip(group['V1 x'],group['V1 y'])),list(zip(group['V2 x'],group['V2 y']))))
    end_point_counts = [(counter_dict[i[0]],counter_dict[i[1]]) for i in end_point_pairs]
    
    group['long branch'] = group['Branch length']>branch_cutoff
    group['is not end'] = [np.min(i)>1 for i in end_point_counts]
    #group = group[np.logical_or(,group['is not end'])]
    
    group['score'] = [np.min([2,sum(i)]) for i in list(zip(2*group['long branch'],group['is not end']))] #长branch +2分，是中间+1分，要求至少5分
    #print(group)
    
    all_points_score1 = list(zip(list(zip(group['V1 x'],group['V1 y'])),group['score']))
    all_points_score2 = list(zip(list(zip(group['V2 x'],group['V2 y'])),group['score']))
    
    #print(group)
    all_points_score = {}
    for lst in [all_points_score1,all_points_score2]:
        for point,score in lst:
            try:
                all_points_score[point] += score
            except KeyError:
                all_points_score[point] = score
    counter_dict = Counter(all_points)
    intersects = [i for i in all_points_score.keys() if all_points_score[i]>=5]
    intersection_num = len(intersects)
    #对每个intersect，看它所在的所有branch
    #print(intersects)
    #aggregated_points, labels = aggregate_points(intersects, distance_threshold=distance_threshold)
    #print(len(intersects),len(aggregated_points))
    return intersection_num,intersects